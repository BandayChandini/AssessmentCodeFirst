﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Purchase_Order_Processing_System.Migrations
{
    /// <inheritdoc />
    public partial class API : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Items",
                columns: table => new
                {
                    ITCode = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    ITDesc = table.Column<string>(type: "varchar(15)", maxLength: 15, nullable: false),
                    ITRate = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Items", x => x.ITCode);
                });

            migrationBuilder.CreateTable(
                name: "Suppliers",
                columns: table => new
                {
                    SuplNo = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    SuplName = table.Column<string>(type: "varchar(15)", maxLength: 15, nullable: false),
                    Supladdr = table.Column<string>(type: "varchar(40)", maxLength: 40, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Suppliers", x => x.SuplNo);
                });

            migrationBuilder.CreateTable(
                name: "Pomasters",
                columns: table => new
                {
                    Pono = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    PoDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ITCode = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false),
                    Qty = table.Column<int>(type: "int", nullable: false),
                    suplno = table.Column<string>(type: "char(4)", maxLength: 4, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Pomasters", x => x.Pono);
                    table.ForeignKey(
                        name: "FK_Pomasters_Items_ITCode",
                        column: x => x.ITCode,
                        principalTable: "Items",
                        principalColumn: "ITCode",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Pomasters_Suppliers_suplno",
                        column: x => x.suplno,
                        principalTable: "Suppliers",
                        principalColumn: "SuplNo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Pomasters_ITCode",
                table: "Pomasters",
                column: "ITCode");

            migrationBuilder.CreateIndex(
                name: "IX_Pomasters_suplno",
                table: "Pomasters",
                column: "suplno");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Pomasters");

            migrationBuilder.DropTable(
                name: "Items");

            migrationBuilder.DropTable(
                name: "Suppliers");
        }
    }
}
