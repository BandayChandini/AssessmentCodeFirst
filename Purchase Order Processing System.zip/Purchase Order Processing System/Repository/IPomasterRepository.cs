﻿using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repository
{
    public interface IPomasterRepository
    {
        Task Add(Pomaster pomaster);
        Task<Pomaster> GetpomasterById(string pono);
        Task<List<Pomaster>> GetAllPomasters();
        Task Delete(string pono);
        Task Update(Pomaster pomaster);
    }
}
