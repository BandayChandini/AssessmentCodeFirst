﻿using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repository
{
    public interface IItemRepository
    {
        Task Add(Item item);
        Task<Item> GetItemById(string ITCode);
        Task<List<Item>> GetAllItems();
        Task Delete(string ITCode);
        Task Update(Item item);
    }
}
