﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System.Entities;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;

namespace Purchase_Order_Processing_System.Repository
{
    public class PomasterRepository : IPomasterRepository
    {
        private readonly POPSContext _context;
        private IConfiguration _configuration;

        public PomasterRepository(POPSContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task Add(Pomaster pomaster)
        {
            _context.Pomasters.Add(pomaster);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string pono)
        {
            var Pomaster = await _context.Pomasters.FindAsync(pono);
            _context.Pomasters.Remove(Pomaster);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Pomaster>> GetAllPomasters()
        {
            return await _context.Pomasters.ToListAsync();
        }

        public async Task<Pomaster> GetpomasterById(string pono)
        {
            var Pomaster = await _context.Pomasters.FindAsync(pono);
            return Pomaster;
        }

        public async Task Update(Pomaster pomaster)
        {
            _context.Pomasters.Update(pomaster);
            await _context.SaveChangesAsync();
        }
    }
}
