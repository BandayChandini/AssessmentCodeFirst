﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repository
{
    public class ItemRepository:IItemRepository
    {
        private readonly POPSContext _context;
        private IConfiguration _configuration;

        public ItemRepository(POPSContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task Add(Item item)
        {
            _context.Items.Add(item);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(string ITCode)
        {
            var Item =await _context.Items.FindAsync(ITCode);
             _context.Items.Remove(Item);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Item>> GetAllItems()
        {
            return await _context.Items.ToListAsync();
        }

        public async Task<Item> GetItemById(string ITCode)
        {
            var Item= await _context.Items.FindAsync(ITCode);
            return Item;
        }

        public async Task Update(Item item)
        {
             _context.Items.Update(item);
            await _context.SaveChangesAsync();
        }
    }
}
