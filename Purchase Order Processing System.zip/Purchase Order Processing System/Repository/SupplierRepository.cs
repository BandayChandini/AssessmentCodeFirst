﻿using Microsoft.EntityFrameworkCore;
using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repository
{
    public class SupplierRepository : ISupplierRepository
    {
        private readonly POPSContext _context;
        private IConfiguration _configuration;

        public SupplierRepository(POPSContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task Add(Supplier supplier)
        {
            await _context.Suppliers.AddAsync(supplier);
            await _context.SaveChangesAsync();
        }
        public async Task Delete(string suplno)
        {
            var supplier= await _context.Suppliers.FindAsync(suplno);
             _context.Suppliers.Remove(supplier);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Supplier>> GetAllSuppliers()
        {
            return await _context.Suppliers.ToListAsync();
        }

        public async Task<Supplier> GetSupplierById(string suplno)
        {
            var supplier = await _context.Suppliers.FindAsync(suplno);
            return supplier;
        }

        public async Task Update(Supplier supplier)
        {
            _context.Suppliers.Update(supplier);
            await _context.SaveChangesAsync();
        }
    }
}
