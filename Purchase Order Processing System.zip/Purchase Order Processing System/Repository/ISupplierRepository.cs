﻿using Purchase_Order_Processing_System.Entities;

namespace Purchase_Order_Processing_System.Repository
{
    public interface ISupplierRepository
    {
        Task Add(Supplier supplier);
        Task<Supplier> GetSupplierById(string suplno);
        Task<List<Supplier>> GetAllSuppliers();
        Task Delete(string suplno);
        Task Update(Supplier supplier);
    }
}
