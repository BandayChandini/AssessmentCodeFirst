﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Purchase_Order_Processing_System.Entities
{
    public class Pomaster
    {
        [Key]
        [Required(ErrorMessage = "pono is required")]
        [Column(TypeName = "char(4)")]
        [StringLength(4, ErrorMessage = "Id must be 4 characters long")]
        
        public string Pono {  get; set; }
        public DateTime PoDate { get; set; }
        [Required(ErrorMessage = "ITcode is required")]
        [Column(TypeName = "char(4)")]
        [StringLength(4, ErrorMessage = "ITcode must be 4 characters long")]
        [ForeignKey("Item")]
        public string ITCode {  get; set; }
        [Required(ErrorMessage = "Qty is required")]
        public int Qty {  get; set; }
        [Required(ErrorMessage = "Suplno is required")]
        [Column(TypeName = "char(4)")]
        [StringLength(4, ErrorMessage = "suplno must be 4 characters long")]
        [ForeignKey("Supplier")]
        public string suplno {  get; set; }
        [JsonIgnore]
        public Item? Item { get; set; }
        [JsonIgnore]
        public Supplier? Supplier { get; set; }
    }
}
