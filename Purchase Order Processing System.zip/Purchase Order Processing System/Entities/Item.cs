﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlTypes;

namespace Purchase_Order_Processing_System.Entities
{
    public class Item
    {
        [Key]
        [Required(ErrorMessage = "ITCode is required")]
        [Column(TypeName = "char(4)")]
        [StringLength(4, ErrorMessage = "ITCode must be 4 characters long")]
        
        public string ITCode { get; set; }
        
        [Column(TypeName = "varchar")]
        [StringLength(15)]

        public string ITDesc {  get; set; }
        [Required(ErrorMessage = "ITRateis required")]
        public decimal ITRate { get; set; }
    }
}
