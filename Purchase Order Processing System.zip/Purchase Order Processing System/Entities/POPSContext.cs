﻿using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Purchase_Order_Processing_System.Entities
{
    public class POPSContext:DbContext
    {
        private IConfiguration configuration;

        public POPSContext(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Pomaster> Pomasters { get; set; }
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("POPSConnection"));
        }
        

    }
}
