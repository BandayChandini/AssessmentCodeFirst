﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Purchase_Order_Processing_System.Entities
{
    public class Supplier
    {
        [Key]
        [Required(ErrorMessage ="Suplno is required")]
        [Column(TypeName = "char(4)")]
        [StringLength(4, ErrorMessage = "Suplno must be 4 characters long")]
        
        public string SuplNo {  get; set; }
        [Required(ErrorMessage = "SuplName is required")]
        [Column(TypeName ="varchar")]
        [StringLength(15)]
        public string SuplName {  get; set; }
        [Required(ErrorMessage = "Supladdr is required")]
        [Column(TypeName = "varchar")]
        [StringLength(40)]
        public string? Supladdr {  get; set; }
    }
}
