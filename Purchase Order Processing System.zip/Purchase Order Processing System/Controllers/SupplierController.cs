﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entities;
using Purchase_Order_Processing_System.Repository;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly ISupplierRepository _supplierRepository;
        private IConfiguration _configuration;
        public SupplierController(ISupplierRepository supplierRepository, IConfiguration configuration)
        {
            _supplierRepository = supplierRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetSuppliers")]
        public async Task<IActionResult> GetAll()
        {
            var suppliers = await _supplierRepository.GetAllSuppliers();
            return StatusCode(200, suppliers);
        }
        [HttpGet, Route("GetSupplier/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            var supplier = await _supplierRepository.GetSupplierById(id);
            if (supplier != null)
            {
                return StatusCode(200, supplier);
            }
            else
                return StatusCode(404, "Invalid Id");
        }
        [HttpPost, Route("AddSupplier")]
        public async Task<IActionResult> Add([FromBody] Supplier supplier)
        {
            await _supplierRepository.Add(supplier);
            return StatusCode(200, supplier);
        }
        [HttpPut, Route("EditSupplier")]
        public async Task<IActionResult> Edit([FromBody] Supplier supplier)
        {
            await _supplierRepository.Update(supplier);
            return StatusCode(200, supplier);
        }
        [HttpDelete, Route("DeleteSupplier")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            await _supplierRepository.Delete(id);
            return Ok();
        }
    }
}
