﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entities;
using Purchase_Order_Processing_System.Repository;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PomasterController : ControllerBase
    {
        private readonly IPomasterRepository _pomasterRepository;
        private IConfiguration _configuration;
        public PomasterController(IPomasterRepository pomasterRepository, IConfiguration configuration)
        {
            _pomasterRepository = pomasterRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetPoamster")]
        public async Task<IActionResult> GetAll()
        {
            var pomasters = await _pomasterRepository.GetAllPomasters();
            return StatusCode(200, pomasters);
        }
        [HttpGet, Route("GetPomaster/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            var pomaster = await _pomasterRepository.GetpomasterById(id);
            if (pomaster != null)
            {
                return StatusCode(200, pomaster);
            }
            else
                return StatusCode(404, "Invalid Id");
        }
        [HttpPost, Route("AddPomaster")]
        public async Task<IActionResult> Add([FromBody] Pomaster pomaster)
        {
            await _pomasterRepository.Add(pomaster);
            return StatusCode(200, pomaster);
        }
        [HttpPut, Route("EditPomaster")]
        public async Task<IActionResult> Edit([FromBody] Pomaster pomaster)
        {
            await _pomasterRepository.Update(pomaster);
            return StatusCode(200, pomaster);
        }
        [HttpDelete, Route("DeletePomaster")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            await _pomasterRepository.Delete(id);
            return Ok();
        }
    }
}
