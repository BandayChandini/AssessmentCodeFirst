﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Purchase_Order_Processing_System.Entities;
using Purchase_Order_Processing_System.Repository;

namespace Purchase_Order_Processing_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        private readonly IItemRepository _itemRepository;
        private IConfiguration _configuration;
        public ItemController(IItemRepository itemRepository, IConfiguration configuration)
        {
            _itemRepository = itemRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetItems")]
        public async Task<IActionResult> GetAll()
        {
            var Items = await _itemRepository.GetAllItems();
            return StatusCode(200, Items);
        }
        [HttpGet, Route("GetItems/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            var item = await _itemRepository.GetItemById(id);
            if (item != null)
            {
                return StatusCode(200, item);
            }
            else
                return StatusCode(404, "Invalid Id");
        }
        [HttpPost, Route("AddItems")]
        public async Task<IActionResult> Add([FromBody] Item item)
        {
            await _itemRepository.Add(item);
            return StatusCode(200, item);
        }
        [HttpPut, Route("EditItems")]
        public async Task<IActionResult> Edit([FromBody] Item item )
        {
            await _itemRepository.Update(item);
            return StatusCode(200, item);
        }
        [HttpDelete, Route("DeleteItem")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            await _itemRepository.Delete(id);
            return Ok();
        }
    }
}
